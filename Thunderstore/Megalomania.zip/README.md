# Megalomania

Not entirely tested. Contact me on discord @A5TR0spud.
Github repo: https://github.com/A5TR0spud/Megalomania/tree/master

By default:

- Egocentrism increases health, regeneration, armor, damage, crit chance, attack speed, movement speed.
- Egocentrism bombs start at 300% damage instead of 360% but increase in damage by 5% per stack.
- Egocentrism converts 5 items at the start of each stage, instead of endless items over time. This can be changed.
- Egocentrism prefers to convert void items, scrap, and items of high rarity.
- Egocentrism replaces primary skill with Conceit.

Config options include Irradiant Pearl-like stat boosts, bomb generation frequency, bomb damage, how the transformation should happen, when, what items and rarities to prioritize, skills to replace, what skills to replace with.

Prioritized items and rarities are not gauranteed to be chosen, instead they are weighted higher.