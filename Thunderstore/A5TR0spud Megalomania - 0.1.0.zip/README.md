# Megalomania


By default:
Egocentrism increases health, regeneration, armor, damage, crit chance, attack speed, movement speed.
Egocentrism bombs start at 200% damage instead of 360% but increase in damage by 10% per stack.
Egocentrism converts 5 items at the start of each stage, instead of endless items over time. This can be changed.
Egocentrism prefers to convert void items, scrap, and items of high rarity.

Config options include Irradient Pearl-like stat boosts, bomb generation frequency, bomb damage, how the transformation should happen, when, what items and rarities to prioritize.

Prioritized items and rarities are not gauranteed to be chosen, instead they are weighted higher.